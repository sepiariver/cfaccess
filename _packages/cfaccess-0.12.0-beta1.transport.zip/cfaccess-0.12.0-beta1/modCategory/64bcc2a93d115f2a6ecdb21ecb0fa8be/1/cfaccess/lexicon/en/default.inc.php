<?php
/**
 * English Lexicon Entries for cfaccess
 *
 * @package cfaccess
 * @subpackage lexicon
 *
 */